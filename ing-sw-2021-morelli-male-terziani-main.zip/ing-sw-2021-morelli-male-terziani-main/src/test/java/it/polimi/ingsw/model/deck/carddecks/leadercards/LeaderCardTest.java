package it.polimi.ingsw.model.deck.carddecks.leadercards;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LeaderCardTest {

    private LeaderCard lcard;


    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getVictoryPointTest() {
    }

    @Test
    public void getRequirementTest() {
    }

    @Test
    public void setVictoryPointTest() {
    }
    
}