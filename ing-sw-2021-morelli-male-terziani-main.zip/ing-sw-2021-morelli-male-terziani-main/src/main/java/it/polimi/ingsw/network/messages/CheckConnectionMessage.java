package it.polimi.ingsw.network.messages;

import it.polimi.ingsw.view.LocalModel;

public class CheckConnectionMessage implements Message{
    @Override
    public void action(LocalModel localModel) {

    }
}
